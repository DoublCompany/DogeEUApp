package com.example.markus.dogeeuapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Markus on 10.02.2018.
 */

public class Tab2Members extends Fragment {
    private static final String TAG = "Tab2Members";
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab2_members, container, false);

       ListView listView = view.findViewById(R.id.listViewMember);

       Member cedric = new Member("hemmer7", "Cedric", "TS Admin/Steam group leader" );
       Member philip = new Member("RebornNX", "Philip", "active member" );
       Member emre = new Member("Painless", "Emre", "active member" );
       Member baran = new Member("Vollkornbrot1708", "Baran", "active member" );
       Member leon = new Member("Nelu", "Leon", "TS Admin/developer" );
       Member lucas = new Member("N0_Escape", "Lucas", "developer" );
       Member markus = new Member("RoccetNX", "Markus", "developer" );
        Member jonas = new Member("seperenstan", "Jonas", "active member" );
        Member lucan = new Member("James Tryharden", "Lucan", "active member" );
        Member ramon = new Member("m1lkhunter", "Ramon", "active member" );
        Member niklas = new Member("TronicNX", "Niklas", "member" );
        Member lukas = new Member("LKSCrafter", "Lukas", "member" );
        Member jafar = new Member("RikoduSennin262", "Jafar", "member" );

        ArrayList<Member> memberList = new ArrayList<>();

        memberList.add(cedric);
        memberList.add(leon);
        memberList.add(lucas);
        memberList.add(markus);
        memberList.add(philip);
        memberList.add(emre);
        memberList.add(baran);
        memberList.add(jonas);
        memberList.add(lucan);
        memberList.add(ramon);
        memberList.add(niklas);
        memberList.add(lukas);
        memberList.add(jafar);

        MemberListAdapter memberListAdapter = new MemberListAdapter(getActivity(), R.layout.adapter_view_members_layout, memberList);
        listView.setAdapter(memberListAdapter);

        return view;
    }
}
