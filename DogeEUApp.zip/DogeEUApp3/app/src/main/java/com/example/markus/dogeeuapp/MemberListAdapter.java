package com.example.markus.dogeeuapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Markus on 10.02.2018.
 */

public class MemberListAdapter extends ArrayAdapter<Member> {

    private static final String TAG = "MemberListAdapter";

    private Context mContext;

    private int mResource;

    public MemberListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Member> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String name = getItem(position).getName();
        String igName = getItem(position).getIgName();
        String status = getItem(position).getStatus();

        Member member = new Member(igName,name,status);

        LayoutInflater inflater = LayoutInflater.from(mContext);

        convertView = inflater.inflate(mResource, parent, false);

        TextView tvIgName = convertView.findViewById(R.id.textViewIgName);
        TextView tvName = convertView.findViewById(R.id.textViewName);
        TextView tvStatus = convertView.findViewById(R.id.textViewStatus);

        tvIgName.setText(igName);
        tvName.setText(name);
        tvStatus.setText(status);

        return convertView;

    }
}
