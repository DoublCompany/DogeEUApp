package com.example.markus.dogeeuapp;

/**
 * Created by Markus on 10.02.2018.
 */

public class Member {
    private String igName;
    private String name;
    private String status;


    public Member(String igName, String name, String status) {
        this.igName = igName;
        this.name = name;
        this.status = status;
    }

    public String getIgName() {
        return igName;
    }

    public void setIgName(String igName) {
        this.igName = igName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }



}
